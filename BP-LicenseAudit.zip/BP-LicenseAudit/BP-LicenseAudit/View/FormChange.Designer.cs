﻿namespace BP_LicenseAudit.View
{
    partial class FormChange
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCzip = new System.Windows.Forms.TextBox();
            this.txtCStreetNr = new System.Windows.Forms.TextBox();
            this.txtCCity = new System.Windows.Forms.TextBox();
            this.txtCStreet = new System.Windows.Forms.TextBox();
            this.txtCName = new System.Windows.Forms.TextBox();
            this.lblCzip = new System.Windows.Forms.Label();
            this.lblCCity = new System.Windows.Forms.Label();
            this.lblCStreetNr = new System.Windows.Forms.Label();
            this.lblCStreet = new System.Windows.Forms.Label();
            this.lblCName = new System.Windows.Forms.Label();
            this.btnCustomer = new System.Windows.Forms.Button();
            this.lblLicense = new System.Windows.Forms.Label();
            this.lstLicense = new System.Windows.Forms.ListBox();
            this.lstNetwork = new System.Windows.Forms.ListBox();
            this.lblNetwork = new System.Windows.Forms.Label();
            this.tabNetwork = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblNetworkEndadress = new System.Windows.Forms.Label();
            this.lblNetworkStart = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblLicense2 = new System.Windows.Forms.Label();
            this.cmbLicense = new System.Windows.Forms.ComboBox();
            this.lblCount = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.btnLicense = new System.Windows.Forms.Button();
            this.btnNetwork = new System.Windows.Forms.Button();
            this.tabNetwork.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtCzip
            // 
            this.txtCzip.Location = new System.Drawing.Point(281, 90);
            this.txtCzip.Name = "txtCzip";
            this.txtCzip.Size = new System.Drawing.Size(141, 20);
            this.txtCzip.TabIndex = 21;
            // 
            // txtCStreetNr
            // 
            this.txtCStreetNr.Location = new System.Drawing.Point(281, 61);
            this.txtCStreetNr.Name = "txtCStreetNr";
            this.txtCStreetNr.Size = new System.Drawing.Size(141, 20);
            this.txtCStreetNr.TabIndex = 20;
            // 
            // txtCCity
            // 
            this.txtCCity.Location = new System.Drawing.Point(59, 90);
            this.txtCCity.Name = "txtCCity";
            this.txtCCity.Size = new System.Drawing.Size(163, 20);
            this.txtCCity.TabIndex = 19;
            // 
            // txtCStreet
            // 
            this.txtCStreet.Location = new System.Drawing.Point(59, 61);
            this.txtCStreet.Name = "txtCStreet";
            this.txtCStreet.Size = new System.Drawing.Size(163, 20);
            this.txtCStreet.TabIndex = 18;
            // 
            // txtCName
            // 
            this.txtCName.Location = new System.Drawing.Point(59, 33);
            this.txtCName.Name = "txtCName";
            this.txtCName.Size = new System.Drawing.Size(363, 20);
            this.txtCName.TabIndex = 17;
            // 
            // lblCzip
            // 
            this.lblCzip.AutoSize = true;
            this.lblCzip.Location = new System.Drawing.Point(251, 93);
            this.lblCzip.Name = "lblCzip";
            this.lblCzip.Size = new System.Drawing.Size(30, 13);
            this.lblCzip.TabIndex = 16;
            this.lblCzip.Text = "PLZ:";
            // 
            // lblCCity
            // 
            this.lblCCity.AutoSize = true;
            this.lblCCity.Location = new System.Drawing.Point(12, 93);
            this.lblCCity.Name = "lblCCity";
            this.lblCCity.Size = new System.Drawing.Size(24, 13);
            this.lblCCity.TabIndex = 15;
            this.lblCCity.Text = "Ort:";
            // 
            // lblCStreetNr
            // 
            this.lblCStreetNr.AutoSize = true;
            this.lblCStreetNr.Location = new System.Drawing.Point(251, 64);
            this.lblCStreetNr.Name = "lblCStreetNr";
            this.lblCStreetNr.Size = new System.Drawing.Size(24, 13);
            this.lblCStreetNr.TabIndex = 14;
            this.lblCStreetNr.Text = "Nr.:";
            // 
            // lblCStreet
            // 
            this.lblCStreet.AutoSize = true;
            this.lblCStreet.Location = new System.Drawing.Point(12, 64);
            this.lblCStreet.Name = "lblCStreet";
            this.lblCStreet.Size = new System.Drawing.Size(45, 13);
            this.lblCStreet.TabIndex = 13;
            this.lblCStreet.Text = "Strasse:";
            // 
            // lblCName
            // 
            this.lblCName.AutoSize = true;
            this.lblCName.Location = new System.Drawing.Point(12, 36);
            this.lblCName.Name = "lblCName";
            this.lblCName.Size = new System.Drawing.Size(38, 13);
            this.lblCName.TabIndex = 12;
            this.lblCName.Text = "Name:";
            // 
            // btnCustomer
            // 
            this.btnCustomer.Location = new System.Drawing.Point(445, 51);
            this.btnCustomer.Name = "btnCustomer";
            this.btnCustomer.Size = new System.Drawing.Size(119, 38);
            this.btnCustomer.TabIndex = 22;
            this.btnCustomer.Text = "Stammdaten ändern";
            this.btnCustomer.UseVisualStyleBackColor = true;
            // 
            // lblLicense
            // 
            this.lblLicense.AutoSize = true;
            this.lblLicense.Location = new System.Drawing.Point(12, 124);
            this.lblLicense.Name = "lblLicense";
            this.lblLicense.Size = new System.Drawing.Size(52, 13);
            this.lblLicense.TabIndex = 23;
            this.lblLicense.Text = "Lizenzen:";
            // 
            // lstLicense
            // 
            this.lstLicense.FormattingEnabled = true;
            this.lstLicense.Items.AddRange(new object[] {
            "(leer)"});
            this.lstLicense.Location = new System.Drawing.Point(15, 141);
            this.lstLicense.Name = "lstLicense";
            this.lstLicense.Size = new System.Drawing.Size(120, 160);
            this.lstLicense.TabIndex = 24;
            // 
            // lstNetwork
            // 
            this.lstNetwork.FormattingEnabled = true;
            this.lstNetwork.Items.AddRange(new object[] {
            "(leer)"});
            this.lstNetwork.Location = new System.Drawing.Point(15, 333);
            this.lstNetwork.Name = "lstNetwork";
            this.lstNetwork.Size = new System.Drawing.Size(120, 160);
            this.lstNetwork.TabIndex = 26;
            // 
            // lblNetwork
            // 
            this.lblNetwork.AutoSize = true;
            this.lblNetwork.Location = new System.Drawing.Point(12, 317);
            this.lblNetwork.Name = "lblNetwork";
            this.lblNetwork.Size = new System.Drawing.Size(61, 13);
            this.lblNetwork.TabIndex = 25;
            this.lblNetwork.Text = "Netzwerke:";
            // 
            // tabNetwork
            // 
            this.tabNetwork.Controls.Add(this.tabPage1);
            this.tabNetwork.Controls.Add(this.tabPage2);
            this.tabNetwork.Controls.Add(this.tabPage3);
            this.tabNetwork.Location = new System.Drawing.Point(154, 333);
            this.tabNetwork.Name = "tabNetwork";
            this.tabNetwork.SelectedIndex = 0;
            this.tabNetwork.Size = new System.Drawing.Size(272, 117);
            this.tabNetwork.TabIndex = 27;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.textBox5);
            this.tabPage1.Controls.Add(this.textBox6);
            this.tabPage1.Controls.Add(this.textBox7);
            this.tabPage1.Controls.Add(this.textBox8);
            this.tabPage1.Controls.Add(this.textBox3);
            this.tabPage1.Controls.Add(this.textBox4);
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.lblNetworkEndadress);
            this.tabPage1.Controls.Add(this.lblNetworkStart);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(264, 91);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Start / End";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(205, 45);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(38, 20);
            this.textBox5.TabIndex = 9;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(161, 45);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(38, 20);
            this.textBox6.TabIndex = 8;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(117, 45);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(38, 20);
            this.textBox7.TabIndex = 7;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(73, 45);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(38, 20);
            this.textBox8.TabIndex = 6;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(205, 13);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(38, 20);
            this.textBox3.TabIndex = 5;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(161, 13);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(38, 20);
            this.textBox4.TabIndex = 4;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(117, 13);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(38, 20);
            this.textBox2.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(73, 13);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(38, 20);
            this.textBox1.TabIndex = 2;
            // 
            // lblNetworkEndadress
            // 
            this.lblNetworkEndadress.AutoSize = true;
            this.lblNetworkEndadress.Location = new System.Drawing.Point(7, 48);
            this.lblNetworkEndadress.Name = "lblNetworkEndadress";
            this.lblNetworkEndadress.Size = new System.Drawing.Size(66, 13);
            this.lblNetworkEndadress.TabIndex = 1;
            this.lblNetworkEndadress.Text = "Endadresse:";
            // 
            // lblNetworkStart
            // 
            this.lblNetworkStart.AutoSize = true;
            this.lblNetworkStart.Location = new System.Drawing.Point(7, 16);
            this.lblNetworkStart.Name = "lblNetworkStart";
            this.lblNetworkStart.Size = new System.Drawing.Size(69, 13);
            this.lblNetworkStart.TabIndex = 0;
            this.lblNetworkStart.Text = "Startadresse:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.textBox9);
            this.tabPage2.Controls.Add(this.textBox10);
            this.tabPage2.Controls.Add(this.textBox11);
            this.tabPage2.Controls.Add(this.textBox12);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(264, 91);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Host";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(208, 19);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(38, 20);
            this.textBox9.TabIndex = 9;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(164, 19);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(38, 20);
            this.textBox10.TabIndex = 8;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(120, 19);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(38, 20);
            this.textBox11.TabIndex = 7;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(76, 19);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(38, 20);
            this.textBox12.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hostadresse:";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.textBox17);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.textBox13);
            this.tabPage3.Controls.Add(this.textBox14);
            this.tabPage3.Controls.Add(this.textBox15);
            this.tabPage3.Controls.Add(this.textBox16);
            this.tabPage3.Controls.Add(this.label2);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(264, 91);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "CIDR";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(196, 38);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(38, 20);
            this.textBox17.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(180, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(15, 24);
            this.label3.TabIndex = 10;
            this.label3.Text = "/";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(141, 38);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(38, 20);
            this.textBox13.TabIndex = 9;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(97, 38);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(38, 20);
            this.textBox14.TabIndex = 8;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(53, 38);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(38, 20);
            this.textBox15.TabIndex = 7;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(9, 38);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(38, 20);
            this.textBox16.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Netzwerk:";
            // 
            // lblLicense2
            // 
            this.lblLicense2.AutoSize = true;
            this.lblLicense2.Location = new System.Drawing.Point(151, 141);
            this.lblLicense2.Name = "lblLicense2";
            this.lblLicense2.Size = new System.Drawing.Size(40, 13);
            this.lblLicense2.TabIndex = 28;
            this.lblLicense2.Text = "Lizenz:";
            // 
            // cmbLicense
            // 
            this.cmbLicense.FormattingEnabled = true;
            this.cmbLicense.Location = new System.Drawing.Point(211, 138);
            this.cmbLicense.Name = "cmbLicense";
            this.cmbLicense.Size = new System.Drawing.Size(211, 21);
            this.cmbLicense.TabIndex = 29;
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.Location = new System.Drawing.Point(151, 173);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(42, 13);
            this.lblCount.TabIndex = 30;
            this.lblCount.Text = "Anzahl:";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(211, 171);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(211, 20);
            this.numericUpDown1.TabIndex = 31;
            // 
            // btnLicense
            // 
            this.btnLicense.Location = new System.Drawing.Point(442, 148);
            this.btnLicense.Name = "btnLicense";
            this.btnLicense.Size = new System.Drawing.Size(119, 38);
            this.btnLicense.TabIndex = 32;
            this.btnLicense.Text = "Lizenz ändern";
            this.btnLicense.UseVisualStyleBackColor = true;
            // 
            // btnNetwork
            // 
            this.btnNetwork.Location = new System.Drawing.Point(442, 355);
            this.btnNetwork.Name = "btnNetwork";
            this.btnNetwork.Size = new System.Drawing.Size(119, 38);
            this.btnNetwork.TabIndex = 33;
            this.btnNetwork.Text = "Netzwerk ändern";
            this.btnNetwork.UseVisualStyleBackColor = true;
            //
            //inherited Elements
            //
            // 
            // cmbCustomer
            // 
            this.cmbCustomer.Location = new System.Drawing.Point(59, 6);
            this.cmbCustomer.Size = new System.Drawing.Size(363, 21);
            this.cmbCustomer.TabIndex = 7;
            // 
            // lblCustomer
            // 
            this.lblCustomer.Location = new System.Drawing.Point(12, 9);
            this.lblCustomer.Size = new System.Drawing.Size(41, 13);
            this.lblCustomer.TabIndex = 6;
            // 
            // btnEnd
            // 
            this.btnEnd.Location = new System.Drawing.Point(442, 455);
            this.btnEnd.Size = new System.Drawing.Size(119, 38);
            this.btnEnd.TabIndex = 34;

            // 
            // FormChange
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(573, 505);
            this.Controls.Add(this.btnNetwork);
            this.Controls.Add(this.btnLicense);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.lblCount);
            this.Controls.Add(this.cmbLicense);
            this.Controls.Add(this.lblLicense2);
            this.Controls.Add(this.tabNetwork);
            this.Controls.Add(this.lstNetwork);
            this.Controls.Add(this.lblNetwork);
            this.Controls.Add(this.lstLicense);
            this.Controls.Add(this.lblLicense);
            this.Controls.Add(this.btnCustomer);
            this.Controls.Add(this.txtCzip);
            this.Controls.Add(this.txtCStreetNr);
            this.Controls.Add(this.txtCCity);
            this.Controls.Add(this.txtCStreet);
            this.Controls.Add(this.txtCName);
            this.Controls.Add(this.lblCzip);
            this.Controls.Add(this.lblCCity);
            this.Controls.Add(this.lblCStreetNr);
            this.Controls.Add(this.lblCStreet);
            this.Controls.Add(this.lblCName);
            this.Name = "FormChange";
            this.Text = "Daten ändern";
            this.Load += new System.EventHandler(this.FormChange_Load);
            this.tabNetwork.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtCzip;
        private System.Windows.Forms.TextBox txtCStreetNr;
        private System.Windows.Forms.TextBox txtCCity;
        private System.Windows.Forms.TextBox txtCStreet;
        private System.Windows.Forms.TextBox txtCName;
        private System.Windows.Forms.Label lblCzip;
        private System.Windows.Forms.Label lblCCity;
        private System.Windows.Forms.Label lblCStreetNr;
        private System.Windows.Forms.Label lblCStreet;
        private System.Windows.Forms.Label lblCName;
        private System.Windows.Forms.Button btnCustomer;
        private System.Windows.Forms.Label lblLicense;
        private System.Windows.Forms.ListBox lstLicense;
        private System.Windows.Forms.ListBox lstNetwork;
        private System.Windows.Forms.Label lblNetwork;
        private System.Windows.Forms.TabControl tabNetwork;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblNetworkEndadress;
        private System.Windows.Forms.Label lblNetworkStart;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblLicense2;
        private System.Windows.Forms.ComboBox cmbLicense;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Button btnLicense;
        private System.Windows.Forms.Button btnNetwork;
    }
}